import { useEffect, useState } from 'react'

const useSVG = (fileName) => {
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)
    const [svg, setSVG] = useState(null)

    useEffect(() => {
        const fetchSVG = async () => {
            try {
                const response = await import(`../assets/images/${fileName}`)
                setSVG(response.default)
            } catch (err) {
                setError(err)
            } finally {
                setLoading(false)
            }
        }

        fetchSVG()
    }, [fileName])

    return {
        loading,
        error,
        svg,
    }
}

export default useSVG