import React from 'react';
import ComputerIcon from "../../assets/images/com.svg";
import TimerIcon from "../../assets/images/timer.svg";

function CartWidget() {
    return (
        <div className="cart-widget">
            <h3>Your Cart</h3>
            <div className="selected-type">
                <span>Selected Type:</span>
                <div className="feature">
                    <img src={ComputerIcon} alt="computer" />
                    <span>Personal Desk</span>
                </div>
            </div>
            <div className="total-hours">
                <span>Total Hours:</span>
                <div className="feature">
                    <img src={TimerIcon} alt="timer" />
                    <span>4 Hours</span>
                </div>
            </div>
            <div className="total-price">
                <span>Total Price:</span>
                <span className="price">$48</span>
            </div>
        </div>
    )
}

export default CartWidget;