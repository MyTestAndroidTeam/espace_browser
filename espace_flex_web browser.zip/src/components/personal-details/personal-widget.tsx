import React, { useState } from 'react';
// import 'react-phone-number-input/style.css';
import 'react-phone-input-2/lib/style.css'
import PhoneInput from 'react-phone-input-2';
import { E164Number } from 'libphonenumber-js/types.cjs';
import flags from 'react-phone-number-input/flags';
function PersonalWidget() {
    const [phoneNumber, setPhoneNumber] = useState<E164Number>("12939283");
    return (
        <div className="personal-widget">
            <h3>Personal Details</h3>
            <div className="line">
                <div className="item">
                    <span>Your Name</span>
                    <input type="text" placeholder="Enter your name" />
                </div>
                <div className="item">
                    <span>Your Surname</span>
                    <input type="text" placeholder="Enter your surname" />
                </div>
            </div>
            <div className="line">
                <div className="item">
                    <span>Email Address</span>
                    <input type="email" placeholder="Enter your email address" />
                </div>
                <div className="item">
                    <span>Phone Number</span>
                    {/* <input type="text" placeholder="Enter your name" /> */}
                    <PhoneInput 
                        country={'ca'}
                        inputStyle={{
                            height: '44px', border: '1px solid #D4D4D8', borderRadius: '8px', width:'100%', marginLeft:'6px', fontSize:'16px'
                        }}
                        placeholder="Enter your phone number"
                        value={phoneNumber}
                        onChange={setPhoneNumber}
                         />
                </div>
            </div>
        </div>
    )
}

export default PersonalWidget;