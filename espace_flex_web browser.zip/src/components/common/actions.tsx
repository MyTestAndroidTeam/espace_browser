import { AppDataContext } from 'App';
import React, { useContext } from 'react';

function Actions() {
    const { setAppData, appData }: any = useContext(AppDataContext);
    const onBack = () => {
        setAppData({ ...appData, step: appData.step - 1 });
    }
    const onNext = () => {
        setAppData({ ...appData, step: appData.step + 1 });
    }

    return (
        <div className="actions" >
            <button className="btn btn-secondary" onClick={onBack} > Back </button>
            <button className="btn btn-primary" onClick={onNext}> Next </button>
        </div>
    )
}

export default Actions;