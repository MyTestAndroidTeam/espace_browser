import React, { useContext, useState } from "react";
import { AppDataContext } from "../../App";
import ComImg from "../../assets/images/com.svg";
import TimerIcon from "../../assets/images/timer.svg";
import Visa from "../../assets/images/visa.svg";
import VisaNone from "../../assets/images/visanone.svg";
import Cvvnumber from "../../assets/images/cvvnumber.svg";
import Pay from "../../assets/images/pay.svg";
import Select from 'react-select';

const Payment = () => {
    const { setAppData, appData }: any = useContext(AppDataContext);
    const onBack = () => {
        setAppData({ ...appData, step: 3 });
    }
    const onNext = () => {
        setAppData({ ...appData, step: 5 });
    }

    const [card, setCard] = useState<string>('')

    const handleCardDisplay = () => {
        console.log('sdkfsldf');
        const rawText = card.split(' ').join(''); // Remove old space
        const creditCard = rawText.split(''); // Create card as array
        const resultCard = [];
        creditCard.forEach((t, i) => {
            if (i < 16) {
                if ((i) % 4 === 0 && i !== 0) resultCard.push(' ') // Add space
                resultCard.push(t);
            }
        })
        return resultCard.join('') // Transform card array to string
    }

    const currentYear = new Date().getFullYear();
    const countries = [
        { value: 'Jan', label: 'Jan' },
        { value: 'Feb', label: 'Feb' },
        { value: 'Mar', label: 'Mar' },
        { value: 'Apr', label: 'Apr' },
        { value: 'May', label: 'May' },
        { value: 'Jun', label: 'Jun' },
        { value: 'Jul', label: 'Jul' },
        { value: 'Aug', label: 'Aug' },
        { value: 'Sep', label: 'Sep' },
        { value: 'Oct', label: 'Oct' },
        { value: 'Nov', label: 'Nov' },
        { value: 'Dec', label: 'Dec' },
    ];
    const [
        selectedValue,
        setSelectedValue,
    ] = useState(null);

    const handleRadioChange = (
        value
    ) => {
        setSelectedValue(value);
    };
    const customStyles = {
        control: base => ({
            ...base,
            height: 48,
            minHeight: 44,
            borderRight: 0,
            borderRadius: "8px 1px 1px 8px",
            fontSize: "16px",
        })
    };
    const styles = {
        container: {
            display: "flex",
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
        },
        heading: {
            color: "green",
            textAlign: "center",
        },

        radioButton: {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            accentColor: "red",
        },
        radioLabel: {
            marginLeft: "8px",
            fontSize: "16px",
            color: "#52525B",
        },
        radioRed: {
            border: "2px solid #90DDD0",
        }

    };
    return (
        <React.Fragment>
            <h1>Select payment method </h1>
            <p>Please select payment method that fits you the best</p>
            <div className="detail-widget" >
                <div className="carddetail-item" >
                    <div className="first-title">
                        <p>Select Payment Method</p>
                    </div>
                    <div className="second-title">
                        <div className="input-first">
                            <div className="your-name">
                                <div className="visa-card">
                                    <div style={{marginTop:'4px'}}>
                                        <input
                                            type="radio"
                                            id="option1"
                                            value="option1"
                                            checked={
                                                selectedValue ===
                                                "option1"
                                            }
                                            onChange={() =>
                                                handleRadioChange(
                                                    "option1"
                                                )
                                            }
                                            style={{ backgroundColor: selectedValue ? 'red' : 'white' }}
                                        />
                                        <label
                                            htmlFor="option1"
                                            style={
                                                styles.radioLabel
                                            }
                                        >
                                            Card
                                        </label>
                                    </div>
                                    <div>
                                        <img src={Visa} alt="Visa" />
                                    </div>
                                </div>
                            </div>
                            <div className="your-surename">
                                <div className="visa-card">
                                    <div style={{marginTop:'4px'}}>
                                        <input
                                            type="radio"
                                            id="option2"
                                            value="option2"
                                            checked={
                                                selectedValue ===
                                                "option2"
                                            }
                                            onChange={() =>
                                                handleRadioChange(
                                                    "option2"
                                                )
                                            }
                                            style={styles.radioRed}
                                        />
                                        <label
                                            htmlFor="option1"
                                            style={
                                                styles.radioLabel
                                            }
                                        >
                                            Apple Pay
                                        </label>
                                    </div>
                                    <div>
                                        <img src={Pay} alt="Pay" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="input-second">
                            <div className="your-name">
                                <div className="visa-card">
                                    <div style={{marginTop:'4px'}}>
                                        <input
                                            type="radio"
                                            id="option3"
                                            value="option3"
                                            checked={
                                                selectedValue ===
                                                "option3"
                                            }
                                            onChange={() =>
                                                handleRadioChange(
                                                    "option3"
                                                )
                                            }
                                        />
                                        <label
                                            htmlFor="option3"
                                            style={
                                                styles.radioLabel
                                            }
                                        >
                                            Card
                                        </label>
                                    </div>
                                    <div>
                                        <img src={Visa} alt="Pay" />
                                    </div>
                                </div>
                            </div>

                            <div className="your-surename">
                                <div className="visa-card">
                                    <div style={{marginTop:'4px'}}>
                                        <input
                                            type="radio"
                                            id="option4"
                                            value="option4"
                                            checked={
                                                selectedValue ===
                                                "option4"
                                            }
                                            onChange={() =>
                                                handleRadioChange(
                                                    "option4"
                                                )
                                            }
                                        />
                                        <label
                                            htmlFor="option4"
                                            style={
                                                styles.radioLabel
                                            }
                                        >
                                            Apple Pay
                                        </label>
                                    </div>
                                    <div>
                                        <img src={Pay} alt="Pay" />
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    {selectedValue === "option1" && (
                        <div className="carddetail-item">
                            <div className="card-first-title">
                                <p>Card Detail</p>
                            </div>
                            <div className="card-second-title">
                                <div className="input-first">
                                    <div className="your-name">
                                        <p>Card Number</p>
                                        <div className="fake-input">
                                            <input
                                                onKeyPress={(event) => {
                                                    if (!/[0-9]/.test(event.key)) {
                                                        event.preventDefault();
                                                    }
                                                }}
                                                className="input-surename"
                                                value={handleCardDisplay()}
                                                onChange={(e) => setCard(e.target.value)}
                                                inputMode="numeric"
                                            ></input>
                                            <img src={VisaNone} width="50" alt="card-number" />
                                        </div>
                                    </div>
                                    <div className="your-surename">
                                        <p>Card Holder</p>
                                        <input className="input-surename" ></input>
                                    </div>
                                </div>
                                <div className="input-second" >
                                    <div className="your-surename">
                                        <p>Expired</p>
                                        <div className="select-country">
                                            <div className="input-select-phone">
                                                <Select styles={customStyles}
                                                    options={countries} defaultValue={countries[0]}
                                                    formatOptionLabel={country => (
                                                        <div style={{ fontSize: "16px" }}>
                                                            {country.label}
                                                        </div>
                                                    )}></Select>
                                            </div>
                                            <input className="input-phone" value={currentYear} ></input>
                                        </div>
                                    </div>
                                    <div className="your-name">
                                        <p>CVV</p>
                                        <div className="fake-input">
                                            <input className="input-surename" type="password" ></input>
                                            <img src={Cvvnumber} width="40" alt="cvv" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
                <div className="cart-item" >
                    <div className="first-title">
                        <p>Your Cart</p>
                    </div>
                    <div className="input-first">
                        <div className="your-name">
                            <span>Selected Type:</span>
                            <button className="btn"><img className="btnimage" src={ComImg} alt="com" /><span>Personal Desk</span></button>
                        </div>
                        <div className="your-surename">
                            <span>Total Hours:</span>
                            <button className="btn" > <img className="btntimerimage" src={TimerIcon} alt="timer" /> <span>4 Hours</span></button>
                        </div>
                    </div>
                    <div className="input-second">
                        <div className="your-name">
                            <span>Total Price</span>
                            <span className="yournamespan">$48</span>
                        </div>
                    </div>
                </div>

            </div>
            <div className="actions" >
                <button className="btn btn-secondary" onClick={onBack} > Back </button>
                <button className="btn btn-primary" onClick={onNext} > Confirm Payment </button>
            </div>
        </React.Fragment >
    )
}

export default Payment;