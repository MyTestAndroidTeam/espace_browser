import React, { useContext } from "react";
import { AppDataContext } from "../../App";
import ComImg from "../../assets/images/com.svg";
import TimerIcon from "../../assets/images/timer.svg";
import flag from "../../assets/images/flag.svg";
import Select from 'react-select';

const PersonalDetail = ({ items }) => {
    const { setAppData }: any = useContext(AppDataContext);
    const onBack = () => {
        setAppData({ step: 2, space: items });
    }
    const onNext = () => {
        setAppData({ step: 4, space: items });
    }
    const countries = [
        { value: 'me', image: flag },
        { value: 'rs', image: flag }
    ];
    const customStyles = {
        control: base => ({
            ...base,
            height: 48,
            minHeight: 44,
            borderRight: 0,
            borderRadius: "8px 1px 1px 8px",
        })
    };
    return (
        <React.Fragment>
            <h1>Personal Details</h1>
            <p> Fill in required fields for smooth payment processing. Your information ensures effective communication.</p>
            <div className="detail-widget" >
                <div className="personaldetail-item" >
                    <div className="first-title">
                        <h3>Personal Details</h3>
                    </div>
                    <div className="second-title">
                        <div className="input-first">
                            <div className="your-name">
                                <p>Your Name</p>
                                <input className="input-name" placeholder="Enter your name"></input>
                            </div>
                            <div className="your-surename">
                                <p>Your SureName</p>
                                <input className="input-surename" placeholder="Enter your surename"></input>
                            </div>
                        </div>
                        <div className="input-second">
                            <div className="your-name">
                                <p>Email Address</p>
                                <input className="input-name" placeholder="Enter your email address"></input>
                            </div>

                            <div className="your-surename">
                                <p>Phone Number</p>
                                <div className="select-country">
                                    <div className="input-select-phone">
                                        <Select styles={customStyles}
                                            options={countries} defaultValue={{ value: 'me', image: flag }}
                                            formatOptionLabel={country => (
                                                <div className="country-option">
                                                    <img src={country.image} alt="country" />
                                                </div>
                                            )}></Select>
                                    </div>
                                    <input className="input-phone" type="tel"></input>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div className="cart-item" >
                    <div className="first-title">
                        <p>Your Cart</p>
                    </div>
                    <div className="input-first">
                        <div className="your-name">
                            <span>Selected Type:</span>
                            <button className="btn"> <span>Personal Desk</span></button>
                        </div>
                        <div className="your-surename">
                            <span>Total Hours:</span>
                            <button className="btn" > <img className="btntimerimage" src={TimerIcon} alt="timer" /><span>4 Hours</span></button>
                        </div>
                    </div>
                    <div className="input-second">
                        <div className="your-name">
                            <span>Total Price</span>
                            <span className="yournamespan">$48</span>
                        </div>
                    </div>
                </div>
            </div>
            <div className="actions" >
                <button className="btn btn-secondary" onClick={onBack} > Back </button>
                <button className="btn btn-primary" onClick={onNext}> Next </button>
            </div>
        </React.Fragment >
    )
}

export default PersonalDetail;