import React, { useState, useEffect } from "react";
import CircleLoading from "../../assets/images/circleloading.svg";
import SucPayment from "../schedule/SuccessPayment";

const Loading = ({ items }) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
        //Implementing the setInterval method
        const interval = setInterval(() => {
            setCount(1);
        }, 1000);

        //Clearing the interval
        return () => clearInterval(interval);
    });

    return (
        <React.Fragment>
            {count === 0 ?
                <div className="loading-app" >
                    <div className="loading-app-first">
                        <span> Please wait while we process your payment. </span>
                    </div>
                    <div className="loading-app-second">
                        <span> Thank you for your patience!</span>
                    </div>
                    <div>
                        <img src={CircleLoading} alt="circleloading" />
                    </div>
                </div> : <SucPayment />
            }

        </React.Fragment >
    )
}

export default Loading;