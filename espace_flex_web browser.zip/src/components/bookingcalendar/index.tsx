import React from 'react';
import '../../assets/css/calendar.css';

function BookingCalendar() {
    const availableTimeSlots = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22];
    const startDay = 20;
    return (
        <table cellSpacing={0}>
            <thead>
                <tr>
                    <td></td>
                    <td>Sun<span>{startDay}</span></td>
                    <td>Mon<span>{startDay + 1}</span></td>
                    <td>Tue<span>{startDay + 2}</span></td>
                    <td>Wed<span>{startDay + 3}</span></td>
                    <td>Thu<span>{startDay + 4}</span></td>
                    <td>Fri<span>{startDay + 5}</span></td>
                    <td>Sat<span>{startDay + 6}</span></td>
                </tr>
            </thead>
            <tbody>
                {
                    availableTimeSlots.map((slot) => {
                        return (
                            <tr>
                                <td>{slot > 12 ? `${slot - 12}pm` : `${slot}am`}</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        )
                    })
                }
            </tbody>
        </table>
    )
}
export default BookingCalendar;