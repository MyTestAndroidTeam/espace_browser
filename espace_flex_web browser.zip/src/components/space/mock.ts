const spaces = [
    {
        id: 1,
        name: "Coworking For 1",
        description: "Hourly and daily desk rentals in the common area at a price comparable to what you'd pay for a coffee.",
        location: "7055 Rue Alexandra, Montreal, QC H2S 3J6",
        features: [
            {
                id: 1,
                title: "Free coffee & tea",
                icon: "coffee.svg"
            },
            {
                id: 2,
                title: "Ergonomic workstations",
                icon: "workstation.svg"
            },
        ],
        price: 8
    },
    {
        id: 2,
        name: "Private Meeting Room For 4",
        description: "A private meeting room in an invigorating co-working space on the ground floor of a trendy neighbourhood.",
        location: "7055 Rue Alexandra, Montreal, QC H2S 3J6",
        features: [
            {
                id: 3,
                title: "Blazing Wi-Fi",
                icon: "wifi.svg"
            },
            {
                id: 4,
                title: "Available on-site parking",
                icon: "parking.svg"
            },
        ],
        price: 24
    },
    {
        id: 3,
        name: "Team Office 1",
        description: "Get the convenience of an instantly available team office space for growing your business, startup etc.",
        location: "7055 Rue Alexandra, Montreal, QC H2S 3J6",
        features: [
            {
                id: 5,
                title: "Free printing",
                icon: "printer.svg"
            },
            {
                id: 6,
                title: "Modern lounge areas",
                icon: "lounge.svg"
            },
        ],
        price: 44
    },
];

export { spaces };