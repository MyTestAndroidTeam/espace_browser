import React, { useContext } from "react";
import Image1 from "assets/images/room1.png";
import Image2 from "assets/images/room2.png";
import Image3 from "assets/images/room3.png";
import Location from "../../assets/images/location.svg";
import CarouselNext from "../../assets/images/carousel-next.svg";
import CarouselPrevious from "../../assets/images/carousel-previous.svg";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';
import { AppDataContext } from "../../App";
import "../../assets/css/slider.css";
import useSVG from "hooks/useSVG";

const FeatureItem = ({ item }) => {
    const { svg } = useSVG(item.icon);
    return (
        <div className="feature-wrapper"> <img src={svg} /><span> {item.title} </span></div >
    )
}

function SpaceItem({ item }) {
    const { setAppData }: any = useContext(AppDataContext);
    const onClickItem = () => {
        setAppData({
            step: 2,
            space: item
        })
    }
    return (
        <div className="space-item" >
            <div className="gallery" >
                <Carousel showThumbs={false} renderArrowPrev={(clickHandler, hasPrev) =>
                    hasPrev && (
                        <div className="carousel-slider-prev-button" onClick={clickHandler}>
                            <img src={CarouselPrevious} />
                        </div>
                    )
                } renderArrowNext={(clickHandler, hasNext) =>
                    hasNext && (
                        <div className="carousel-slider-next-button" onClick={clickHandler}>
                            <img src={CarouselNext} />
                        </div>
                    )
                }>
                    <div className="item" >
                        <img src={Image1} alt="space" />
                    </div>
                    <div className="item" >
                        <img src={Image2} alt="space" />
                    </div>
                    <div className="item" >
                        <img src={Image3} alt="space" />
                    </div>
                </Carousel>
            </div>
            <div className="info" onClick={onClickItem} >
                <span className="price" > Starting at {`$${item.price || 0}/h`} </span>
                <h2> {item.name} </h2>
                <p> {item.description} </p>
                <div className="features" >
                    {
                        item.features.length > 0 && item.features.map((feature, idx) => <FeatureItem key={idx} item={feature} />)
                    }
                </div>
                <div className="location-wrapper" >
                    <img src={Location} alt="mark" />
                    <span className="location" > {item.location} </span>
                </div>
            </div>
        </div>
    )
}

export default SpaceItem;