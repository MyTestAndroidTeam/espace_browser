import React from "react";
import SpaceItem from "./Item";

function SpaceList({ spaces }) {
  return (
    <div className="space-list">
      {spaces.length > 0 && spaces.map((space) => <SpaceItem key={space.id} item={space} />)}
    </div>
  )
}

export default SpaceList;